

module.exports = {
  main: {
    users: {
      id: {
        type: "BIGINT",
        null: false,
        comment: "Primary Key",
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      ac_status: {
        type: "ENUM",
        LengthValue:
          "'registered', 'requested', 'approved', 'rejected', 'suspended', 'restricted', 'blocked', 'deleted'",
        null: false,
        default: "registered",
      },
      user_role: {
        type: "ENUM",
        LengthValue:
          "'admin', 'back_end_dev', 'app_dev', 'front_end_dev', 'employee', 'marketer', 'support', 'higher_support', 'advocate', 'user'",
        null: false,
        default: "user",
      },
      first_name: { type: "VARCHAR", LengthValue: 60, null: false },
      last_name: { type: "VARCHAR", LengthValue: 100, null: false },
      display_name: { type: "VARCHAR", LengthValue: 255, null: false },
      bio: { type: "TEXT", null: false },
      profile_title: { type: "VARCHAR", LengthValue: 100, null: false },
      description: { type: "JSON", null: false },
      skills: { type: "TEXT", null: false },
      languages: { type: "JSON", null: false },
      profile_picture: { type: "VARCHAR", LengthValue: 255, null: true },
      cover_picture: { type: "VARCHAR", LengthValue: 255, null: true },
      seller_level: {
        type: "ENUM",
        LengthValue:
          "'none','starter', 'bronze', 'silver', 'gold', 'platinum', 'diamond', 'ruby', 'sapphire', 'emerald', 'obsidian'",
        null: true,
        default: "none",
      },
      accoutn_badges: { type: "JSON", null: true, comment: "List of badges" },
      overall_rating: { type: "FLOAT", null: true },
      avg_response_time: {
        type: "INT",
        null: false,
        comment: "Average response time in hours.",
        default: "0",
      },
      review_count: { type: "INT", null: false, default: "0" },
      follow_count: { type: "BIGINT", null: false, default: "0" },
      following_count: { type: "BIGINT", null: false, default: "0" },
      ideator_level: { type: "VARCHAR", LengthValue: 255, null: true },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    setting: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      user_id: {
        type: "BIGINT",
        null: false,
        foreign_key: {
          table: "users",
          column: "id",
          delete: true,
        },
      },
      p_user_id: {
        type: "BIGINT",
        null: false,
        foreign_key: {
          table: "users",
          column: "id",
          delete: true,
        },
      },
      user_identity: {
        type: "VARCHAR",
        LengthValue: 255,
        null: false,
        index: "UNIQUE",
      },
      username: {
        type: "VARCHAR",
        LengthValue: 50,
        null: true,
        index: "UNIQUE",
      },
      custom_url: {
        type: "VARCHAR",
        LengthValue: 100,
        null: true,
        index: "UNIQUE",
      },
      privacy: {
        type: "TINYINT",
        null: false,
        comment: "3 = public, 2 = only registered users, 1 = private",
        default: "3",
      },
      password: { type: "VARCHAR", LengthValue: 255, null: false },
      primary_email: { type: "INT", null: true },
      primary_phone: { type: "INT", null: true },
      two_step_verify: { type: "TINYINT", null: false, default: "0" },
      two_step_verify_method: {
        type: "ENUM",
        LengthValue: "'none', 'email', 'phone'",
        null: false,
        default: "none",
      },
      blood_group: {
        type: "ENUM",
        LengthValue: "'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'",
        null: true,
      },
      gender: {
        type: "ENUM",
        LengthValue: "'male','female','other'",
        null: false,
      },
      date_of_birth: { type: "DATE", null: false },
      relationship_status: {
        type: "ENUM",
        LengthValue: "'single','married','divorced','widowed','separated'",
        null: false,
        default: "single",
      },
      time_zone: { type: "VARCHAR", LengthValue: 255, null: false },
      currency: { type: "VARCHAR", LengthValue: 5, null: false },
      country: { type: "VARCHAR", LengthValue: 50, null: false },
      state: { type: "VARCHAR", LengthValue: 100, null: false },
      city: { type: "VARCHAR", LengthValue: 100, null: true },
      zip: { type: "VARCHAR", LengthValue: 100, null: false },
      addressline1: { type: "VARCHAR", LengthValue: 255, null: false },
      addressline2: { type: "VARCHAR", LengthValue: 255, null: true },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    reset_password: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      user_id: {
        type: "BIGINT",
        null: false,
        comment: "Foreign key referencing users table",
        foreign_key: {
          table: "users",
          column: "id",
          delete: true,
        },
      },
      email: { type: "VARCHAR", LengthValue: 255, null: false },
      code: { type: "VARCHAR", LengthValue: 10, null: false },
      token: {
        type: "VARCHAR",
        LengthValue: 255,
        null: true,
        index: "UNIQUE",
      },
      expires_at: { type: "TIMESTAMP", null: true },
      email_sent: { type: "TINYINT", null: false, default: "0" },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    linked_account: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      user_id: {
        type: "BIGINT",
        null: false,
        comment: "Foreign key referencing users table",
        foreign_key: {
          table: "users",
          column: "id",
          delete: true,
        },
      },
      provider: {
        type: "VARCHAR",
        LengthValue: 50,
        null: false,
        comment: "The platform name (google, facebook, github etc.)",
      },
      provider_user_id: {
        type: "VARCHAR",
        LengthValue: 100,
        null: false,
        comment: "The platform user id",
      },
      token: {
        type: "VARCHAR",
        LengthValue: 255,
        null: false,
        comment: "The platform provided token",
      },
      full_name: { type: "VARCHAR", LengthValue: 255, null: true },
      date_of_birth: { type: "DATE", null: true },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    ac_preferance: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      user_id: {
        type: "BIGINT",
        null: false,
        comment: "Foreign key referencing users table",
        foreign_key: {
          table: "users",
          column: "id",
          delete: true,
        },
      },
      work_preferance: {
        type: "ENUM",
        LengthValue: "'none','short', 'long', 'both'",
        null: true,
        comment: "Short, long, both",
      },
      freelancing_experience: {
        type: "ENUM",
        LengthValue: "'beginner', 'intermediate', 'expert', 'some experience'",
        null: false,
        default: "beginner",
      },
      working_goal: {
        type: "ENUM",
        LengthValue:
          "'main income', 'side income', 'get some experience', 'just exploring'",
        null: false,
      },
      per_hour_rate: { type: "FLOAT", null: false, default: "0" },
      consultation_time: {
        type: "INT",
        null: true,
        comment:
          "Give minimum amount of time that you will be consulting in minutes. e.g. 60 min which means 1 hour.",
        default: "0",
      },
      consultation_charge: { type: "FLOAT", null: false, default: "0" },
      hours_perWeek: {
        type: "INT",
        null: false,
        comment: "How many hours do you plan to spend per week",
        default: "0",
      },
      on_time: { type: "INT", null: false, default: "0" },
      on_budget: { type: "INT", null: false, default: "0" },
      job_accept_rate: { type: "INT", null: false, default: "0" },
      repeat_hire_rate: { type: "INT", null: false, default: "0" },
      job_release_rate: { type: "INT", null: false, default: "0" },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    investor_preferance: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      user_id: {
        type: "BIGINT",
        null: false,
        comment: "Foreign key referencing users table",
        foreign_key: {
          table: "users",
          column: "id",
          delete: true,
        },
      },
      investor_level: {
        type: "ENUM",
        LengthValue: "'none','short', 'long', 'both'",
        null: true,
        comment: "Short, long, both",
      },
      contact_email: { type: "VARCHAR", LengthValue: 255, null: true },
      country_code: {
        type: "VARCHAR",
        LengthValue: 5,
        null: true,
        comment: "Alpha 2",
      },
      phone_number: { type: "FLOAT", null: false, default: "0" },
      office_address: {
        type: "JSON",
        null: true,
        comment: "Only if available",
      },
      company_name: { type: "VARCHAR", LengthValue: 255, null: true },
      company_address: { type: "JSON", null: false },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    freelancer_interest: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      user_id: {
        type: "BIGINT",
        null: false,
        comment: "Foreign key referencing users table",
        foreign_key: {
          table: "users",
          column: "id",
          delete: true,
        },
      },
      is_seller: { type: "TINYINT", null: false, default: "0" },
      is_buyer: { type: "TINYINT", null: false, default: "0" },
      is_job_seeker: { type: "TINYINT", null: false, default: "0" },
      is_company_owner: { type: "TINYINT", null: false, default: "0" },
      is_investor: { type: "TINYINT", null: false, default: "0" },
      freelancer_countries: {
        type: "JSON",
        null: true,
        comment: "e.g. {country_name: count}",
      },
      freelancer_price: {
        type: "JSON",
        null: true,
        comment: "All prices list that clicked and worked with.",
      },
      freelancer_job_types: {
        type: "JSON",
        null: true,
        comment: "All job list that clicked and worked with.",
      },
      client_countries: {
        type: "JSON",
        null: true,
        comment: "e.g. {country_name: count}",
      },
      client_price: {
        type: "JSON",
        null: true,
        comment: "All prices list that clicked and worked with.",
      },
      client_job_types: {
        type: "JSON",
        null: true,
        comment: "All job list that clicked and worked with.",
      },
      seller_level_interest: {
        type: "JSON",
        null: true,
        comment: "All job list that clicked and worked with.",
      },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    client_interest: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      user_id: {
        type: "BIGINT",
        null: false,
        comment: "Foreign key referencing users table",
        foreign_key: {
          table: "users",
          column: "id",
          delete: true,
        },
      },
      is_seller: { type: "TINYINT", null: false, default: "0" },
      is_buyer: { type: "TINYINT", null: false, default: "0" },
      is_job_seeker: { type: "TINYINT", null: false, default: "0" },
      is_company_owner: { type: "TINYINT", null: false, default: "0" },
      is_investor: { type: "TINYINT", null: false, default: "0" },
      freelancer_countries: {
        type: "JSON",
        null: true,
        comment: "e.g. {country_name: count}",
      },
      freelancer_price: {
        type: "JSON",
        null: true,
        comment: "All prices list that clicked and worked with.",
      },
      freelancer_job_types: {
        type: "JSON",
        null: true,
        comment: "All job list that clicked and worked with.",
      },
      client_countries: {
        type: "JSON",
        null: true,
        comment: "e.g. {country_name: count}",
      },
      client_price: {
        type: "JSON",
        null: true,
        comment: "All prices list that clicked and worked with.",
      },
      client_job_types: {
        type: "JSON",
        null: true,
        comment: "All job list that clicked and worked with.",
      },
      seller_level_interest: {
        type: "JSON",
        null: true,
        comment: "All job list that clicked and worked with.",
      },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    investor_interest: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      user_id: {
        type: "BIGINT",
        null: false,
        comment: "Foreign key referencing users table",
        foreign_key: {
          table: "users",
          column: "id",
          delete: true,
        },
      },
      prices: {
        type: "JSON",
        null: true,
        comment: "All prices list that clicked and worked with.",
      },
      idea_neash: {
        type: "JSON",
        null: true,
        comment: "Ideas types that you like e.g. technology, agriculture, etc.",
      },
      user_countries: {
        type: "JSON",
        null: true,
        comment: "e.g. {country_name: count}",
      },
      ideator_levels: {
        type: "TEXT",
        null: true,
        comment: "Ids of the level of ids",
      },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    platform_charge: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      payment_type: {
        type: "VARCHAR",
        LengthValue: 255,
        comment:
          "deposit, withdrawal, payment, payout, platform_charge, subscription_fee, processing_fee, refund, admin_adjustment, challenge_payment, challenge_refund, bonus, reward transfer, dispute_adjustment, penalty, reversal, admin_adjustment, recruiter_payment",
      },
      charge_percentage: { type: "INT", null: false, default: 15 },
      currency: {
        type: "VARCHAR",
        LengthValue: 3,
        null: false,
        default: "BDT",
      },
      amount: { type: "FLOAT", null: false, default: "0" },
      transaction_id: { type: "VARCHAR", LengthValue: 255, null: false },
      balance_after_transaction: { type: "FLOAT", null: false, default: "0" },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    category: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      user_id: {
        type: "BIGINT",
        null: true,
        comment: "Foreign key referencing users table",
        foreign_key: {
          table: "users",
          column: "id",
          delete: null,
        },
      },
      parent_id: {
        type: "BIGINT",
        null: true,
        comment:
          "Nullable. references category_id for subcategories. NULL for top-level categories.",
        foreign_key: {
          table: "category",
          column: "id",
          delete: null,
        },
      },
      slug: {
        type: "VARCHAR",
        LengthValue: 255,
        comment: "Optional. A URL-friendly identifier for the category.",
        index: "UNIQUE",
      },
      category_name: {
        type: "VARCHAR",
        LengthValue: 255,
        null: false,
        comment: "Name of the category or subcategory.",
        _charset_: "utf8mb4",
        _collate_: "utf8mb4_zh_0900_as_cs"
      },
      category_type: {
        type: "ENUM",
        LengthValue: "'none', 'skills','freelance', 'office_job', 'server'",
        null: false,
        default: "none",
      },
      status: {
        type: "ENUM",
        LengthValue: "'active', 'inactive', 'requested', 'deleted', 'cancel'",
        comment: "Defines whether the category is currently active or not.",
      },
      available_jobs: { type: "INT", null: true, default: "0" },
      popularity_score: {
        type: "INT",
        null: false,
        comment:
          "Score depends on how many project, deal, challenges posted on this skill.",
        default: "0",
      },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP"
      },
      _characterset_: "utf8mb4"
    },
    _charset_: "utf8mb4",
    _collate_: "utf8mb4_zh_0900_as_cs"
  },
  fm: {
    users: {
      id: {
        type: "BIGINT",
        null: false,
        comment: "Primary Key",
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      ac_status: {
        type: "ENUM",
        LengthValue:
          "'registered', 'requested', 'approved', 'rejected', 'suspended', 'restricted', 'blocked', 'deleted'",
        null: false,
        default: "registered",
      },
      user_role: {
        type: "ENUM",
        LengthValue:
          "'admin', 'back_end_dev', 'app_dev', 'front_end_dev', 'employee', 'marketer', 'support', 'higher_support', 'advocate', 'user'",
        null: false,
        default: "user",
      },
      first_name: { type: "VARCHAR", LengthValue: 60, null: false },
      last_name: { type: "VARCHAR", LengthValue: 100, null: false },
      display_name: { type: "VARCHAR", LengthValue: 255, null: false },
      bio: { type: "TEXT", null: false },
      profile_title: { type: "VARCHAR", LengthValue: 100, null: false },
      description: { type: "JSON", null: false },
      skills: { type: "TEXT", null: false },
      languages: { type: "JSON", null: false },
      profile_picture: { type: "VARCHAR", LengthValue: 255, null: true },
      cover_picture: { type: "VARCHAR", LengthValue: 255, null: true },
      seller_level: {
        type: "ENUM",
        LengthValue:
          "'none','starter', 'bronze', 'silver', 'gold', 'platinum', 'diamond', 'ruby', 'sapphire', 'emerald', 'obsidian'",
        null: true,
        default: "none",
      },
      accoutn_badges: { type: "JSON", null: true, comment: "List of badges" },
      avg_response_time: {
        type: "INT",
        null: false,
        comment: "Average response time in hours.",
        default: "0",
      },
      review_count: { type: "INT", null: false, default: "0" },
      follow_count: { type: "BIGINT", null: false, default: "0" },
      following_count: { type: "BIGINT", null: false, default: "0" },
      ideator_level: { type: "VARCHAR", LengthValue: 255, null: true },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    payment_method: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      payment_method: {
        type: "ENUM",
        LengthValue: "'Bank Transfer', 'Mobile Payment', 'PayPal', 'Card'",
        null: false,
      },
      mobile_payNum: { type: "VARCHAR", LengthValue: 15, null: false },
      swift_code: {
        type: "CHAR",
        LengthValue: 8,
        null: false,
        comment: "SWIFT code with standard length",
      },
      account_number: { type: "VARCHAR", LengthValue: 20, null: false },
      post_code: { type: "VARCHAR", LengthValue: 20, null: false },
      account_type: {
        type: "ENUM",
        LengthValue: "'personal', 'company'",
        null: false,
      },
      branch_name: { type: "VARCHAR", LengthValue: 255, null: false },
      branch_address: { type: "VARCHAR", LengthValue: 255, null: false },
      ac_first_name: { type: "VARCHAR", LengthValue: 255, null: false },
      ac_last_name: { type: "VARCHAR", LengthValue: 255, null: false },
      ac_date_of_birth: { type: "DATE", null: false },
      id_type: {
        type: "ENUM",
        LengthValue: "'id', 'passport'",
        null: false,
        comment: "ID number or Passport number",
      },
      customer_id: { type: "VARCHAR", LengthValue: 255, null: false },
      name_on_account: { type: "VARCHAR", LengthValue: 255, null: false },
      ac_address: {
        type: "VARCHAR",
        LengthValue: 500,
        null: false,
        comment: "Physical address associated with this account",
      },
      city_state: { type: "VARCHAR", LengthValue: 255, null: false },
      country: { type: "VARCHAR", LengthValue: 255, null: false },
      phone: { type: "VARCHAR", LengthValue: 15, null: false },
      is_authorized: {
        type: "ENUM",
        LengthValue: "'yes', 'no'",
        null: false,
        comment: "Flag indicating ownership and authorization of account",
        default: "no",
      },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    transaction: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      transaction_type: { type: "VARCHAR", LengthValue: 100, null: false },
      transaction_id: {
        type: "VARCHAR",
        LengthValue: 255,
        null: false,
        index: "UNIQUE",
      },
      reference: { type: "VARCHAR", LengthValue: 255 },
      amount: { type: "FLOAT", null: false, default: "0" },
      customer_name: { type: "VARCHAR", LengthValue: 255, null: false },
      address: {
        type: "VARCHAR",
        LengthValue: 255,
        null: false,
        default: "None",
      },
      payment_method: {
        type: "VARCHAR",
        LengthValue: 255,
        null: false,
        default: "None",
      },
      email: {
        type: "VARCHAR",
        LengthValue: 255,
        null: false,
        default: "None",
      },
      phone: {
        type: "VARCHAR",
        LengthValue: 255,
        null: false,
        default: "None",
      },
      created_at: { type: "TIMESTAMP", null: false, default: "CURRENT_TIMESTAMP" },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    fund_request: {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      from_id: { type: "BIGINT", null: true },
      user_id: { type: "BIGINT", null: true },
      payment_type: {
        type: "ENUM",
        LengthValue: "'deposit', 'withdraw', 'spent', 'earning'",
        null: false,
      },
      reason: {
        type: "ENUM",
        LengthValue:
          "'none', 'deposit', 'withdrawal', 'project_payment', 'payout', 'platform_charge', 'subscription_fee', 'processing_fee', 'refund', 'challenge_payment', 'challenge_refund', 'dispute_adjustment', 'reversal', 'admin_adjustment', 'recruiter_payment', 'check_out'",
        null: false,
      },
      table_name: { type: "VARCHAR", LengthValue: 50, null: true },
      row_id: { type: "BIGINT", null: true },
      job_id: { type: "BIGINT", null: true },
      request_date: { type: "TIMESTAMP", null: false },
      transaction_hold_time: {
        type: "INT",
        null: true,
        comment: "Transaction hold time in hours",
      },
      transaction_date: { type: "TIMESTAMP", null: true },
      transaction_id: { type: "VARCHAR", LengthValue: 255, null: false },
      currency: {
        type: "VARCHAR",
        LengthValue: 3,
        null: false,
        default: "BDT",
      },
      amount: {
        type: "FLOAT",
        null: false,
        default: "0"
      },
      status: {
        type: "ENUM",
        LengthValue:
          "'pending', 'completed', 'failed', 'cancelled', 'processing', 'reversed', 'on_hold', 'refunded', 'approved', 'rejected'",
        null: false,
        default: "pending",
      },
      balance_updated: {
        type: "TINYINT",
        null: false,
        default: "0"
      },
      invoice_sent: {
        type: "TINYINT",
        null: false,
        default: "0"
      },
      remarks: {
        type: "TEXT",
        null: true
      },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
    },
    "(year)balance": {
      id: {
        type: "BIGINT",
        null: false,
        auto_increment: true,
        index: "PRIMARY KEY",
      },
      currency: {
        type: "VARCHAR",
        LengthValue: 5,
        null: false,
        default: "BDT",
      },
      image: { type: "MEDIUMBLOB", null: true },
      balance: { type: "FLOAT", null: true, default: "0", unique: true },
      total_earnings: { type: "FLOAT", null: false, default: "0" },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP",
      },
      updated_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP"
      }
    },
    image_store: {
      id: {
        type: "BIGINT",
        primary: true,
        null: false,
        auto_increment: true
      },
      image: {
        type: "MEDIUMBLOB",
        null: false
      },
      created_at: {
        type: "TIMESTAMP",
        null: false,
        default: "CURRENT_TIMESTAMP"
      }
    },
    advanced_store: {
      // --- Binary / Object Storage ---
      secure_token: {
        type: "BINARY",
        LengthValue: 16,
        null: false
      },
      session_signature: {
        type: "VARBINARY",
        LengthValue: 255,
        null: true
      },
      thumbnail_avatar: {
        type: "TINYBLOB",
        null: true
      },
      user_attachment: {
        type: "BLOB",
        null: true
      },
      media_backup: {
        type: "MEDIUMBLOB",
        null: true
      },
      system_image_dump: {
        type: "LONGBLOB",
        null: true
      },

      account_privileges: {
        type: "SET",
        LengthValue: "'read', 'write', 'execute', 'admin'",
        null: false,
        default: "read"
      },
      audit_metadata: {
        type: "JSON",
        null: true
      },

      // --- Spatial / GIS Geometry Types ---
      generic_shape: {
        type: "GEOMETRY",
        null: true,
        comment: "Can store geometry values of any type"
      },
      location_coordinate: {
        type: "POINT",
        null: true,
        comment: "A single point in space (X, Y / Lat, Long)"
      },
      route_path: {
        type: "LINESTRING",
        null: true,
        comment: "A curve/line connecting multiple point coordinates"
      },
      boundary_zone: {
        type: "POLYGON",
        null: true,
        comment: "A closed multi-sided planar surface area"
      },
      cluster_nodes: {
        type: "MULTIPOINT",
        null: true,
        comment: "A collection of distinct, non-connected points"
      },
      metro_transit_lines: {
        type: "MULTILINESTRING",
        null: true,
        comment: "A collection of multiple independent linestrings"
      },
      territory_regions: {
        type: "MULTIPOLYGON",
        null: true,
        comment: "A collection of separate polygons (e.g., an island chain)"
      },
      spatial_aggregate: {
        type: "GEOMETRYCOLLECTION",
        null: true,
        comment: "A mixed collection of points, lines, and polygons"
      }
    }
  },
};
