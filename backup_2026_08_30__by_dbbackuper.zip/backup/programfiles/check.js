const mysql = require("mysql2/promise")
const fncs = require('./functions');
const path = require("path");
const fs = require("fs").promises;
const v8 = require('v8');
const links = require("./links.js");
const getmtd = require("./getmetadata.js");
const dbtasker = require("dbtasker");
const ff = require("./filefunctions.js")
const rows = require("./getrows.js");
const checkdisk = require("./checkdiskspace.js")
const createbackup = require("./createbackup.js")
const upload = require("./upload.js")
const vldcc = require("./validateUploads.js");
// npm install adm-zip

const DBInfo = {
    port: 3301,
    host: "localhost",
    user: "root",
    password: "1234",
    database: "test",
    waitForConnections: true,
    connectionLimit: 100,
    queueLimit: 0,
};
let config = {
    port: "3301",
    host: "localhost",
    user: "root",
    password: "1234",
}



const mysqlTypeMetadata = {
    // Numeric types
    TINYINT: { lengthType: "int", required: false, query: "TINYINT(3)", supportsUnsigned: true, dataType: "numeric" },
    SMALLINT: { lengthType: "int", required: false, query: "SMALLINT(5)", supportsUnsigned: true, dataType: "numeric" },
    MEDIUMINT: { lengthType: "int", required: false, query: "MEDIUMINT(8)", supportsUnsigned: true, dataType: "numeric" },
    INT: { lengthType: "int", required: false, query: "INT(11)", supportsUnsigned: true, dataType: "numeric" },
    INTEGER: { lengthType: "int", required: false, query: "INTEGER(11)", supportsUnsigned: true, dataType: "numeric" },
    BIGINT: { lengthType: "int", required: false, query: "BIGINT(20)", supportsUnsigned: true, dataType: "numeric" },
    FLOAT: { lengthType: "two-int", required: false, query: "FLOAT(10,2)", supportsUnsigned: true, dataType: "numeric" },
    DOUBLE: { lengthType: "two-int", required: false, query: "DOUBLE(16,4)", supportsUnsigned: true, dataType: "numeric" },
    REAL: { lengthType: "two-int", required: false, query: "REAL(16,4)", supportsUnsigned: true, dataType: "numeric" },
    DECIMAL: { lengthType: "two-int", required: true, query: "DECIMAL(10,2)", supportsUnsigned: true, dataType: "numeric" },
    NUMERIC: { lengthType: "two-int", required: true, query: "NUMERIC(10,2)", supportsUnsigned: true, dataType: "numeric" },

    // Boolean types
    BOOLEAN: { lengthType: "none", required: false, query: "BOOLEAN", supportsUnsigned: false, dataType: "boolean" },
    BOOL: { lengthType: "none", required: false, query: "BOOL", supportsUnsigned: false, dataType: "boolean" },

    // Bit type // you can specify how many bits (1–64)
    BIT: { lengthType: "int", required: true, query: "BIT(1)", supportsUnsigned: false, dataType: "bit" },

    // Date & Time types
    DATE: { lengthType: "none", required: false, query: "DATE", supportsUnsigned: false, dataType: "datetime" },
    TIME: { lengthType: "fsp", required: false, query: "TIME(6)", supportsUnsigned: false, dataType: "datetime" },
    YEAR: { lengthType: "none", required: false, query: "YEAR", supportsUnsigned: false, dataType: "datetime" },
    DATETIME: { lengthType: "fsp", required: false, query: "DATETIME(6)", supportsUnsigned: false, dataType: "datetime" },
    TIMESTAMP: { lengthType: "fsp", required: false, query: "TIMESTAMP(6)", supportsUnsigned: false, dataType: "datetime" },

    // String types
    CHAR: { lengthType: "int", required: true, query: "CHAR(1)", supportsUnsigned: false, dataType: "string" },
    VARCHAR: { lengthType: "int", required: true, query: "VARCHAR(255)", supportsUnsigned: false, dataType: "string" },
    TINYTEXT: { lengthType: "none", required: false, query: "TINYTEXT", supportsUnsigned: false, dataType: "string" },
    TEXT: { lengthType: "none", required: false, query: "TEXT", supportsUnsigned: false, dataType: "string" },
    MEDIUMTEXT: { lengthType: "none", required: false, query: "MEDIUMTEXT", supportsUnsigned: false, dataType: "string" },
    LONGTEXT: { lengthType: "none", required: false, query: "LONGTEXT", supportsUnsigned: false, dataType: "string" },
    ENUM: { lengthType: "list", required: true, query: "ENUM('option1', 'option2')", supportsUnsigned: false, dataType: "text" },
    SET: { lengthType: "list", required: true, query: "SET('a','b','c')", supportsUnsigned: false, dataType: "text" },

    // Binary types
    BINARY: { lengthType: "int", required: true, query: "BINARY(1)", supportsUnsigned: false, dataType: "binary" },
    VARBINARY: { lengthType: "int", required: true, query: "VARBINARY(255)", supportsUnsigned: false, dataType: "binary" },
    TINYBLOB: { lengthType: "none", required: false, query: "TINYBLOB", supportsUnsigned: false, dataType: "binary" },
    BLOB: { lengthType: "none", required: false, query: "BLOB", supportsUnsigned: false, dataType: "binary" },
    MEDIUMBLOB: { lengthType: "none", required: false, query: "MEDIUMBLOB", supportsUnsigned: false, dataType: "binary" },
    LONGBLOB: { lengthType: "none", required: false, query: "LONGBLOB", supportsUnsigned: false, dataType: "binary" },

    // Spatial types
    GEOMETRY: { lengthType: "none", required: false, query: "GEOMETRY", supportsUnsigned: false, dataType: "geometry" },
    POINT: { lengthType: "none", required: false, query: "POINT", supportsUnsigned: false, dataType: "geometry" },
    LINESTRING: { lengthType: "none", required: false, query: "LINESTRING", supportsUnsigned: false, dataType: "geometry" },
    POLYGON: { lengthType: "none", required: false, query: "POLYGON", supportsUnsigned: false, dataType: "geometry" },
    MULTIPOINT: { lengthType: "none", required: false, query: "MULTIPOINT", supportsUnsigned: false, dataType: "geometry" },
    MULTILINESTRING: { lengthType: "none", required: false, query: "MULTILINESTRING", supportsUnsigned: false, dataType: "geometry" },
    MULTIPOLYGON: { lengthType: "none", required: false, query: "MULTIPOLYGON", supportsUnsigned: false, dataType: "geometry" },
    GEOMETRYCOLLECTION: { lengthType: "none", required: false, query: "GEOMETRYCOLLECTION", supportsUnsigned: false, dataType: "geometry" },

    // JSON
    JSON: { lengthType: "none", required: false, query: "JSON", supportsUnsigned: false, dataType: "json" }
};

async function makeReadable(inputFile, outputFile) {
    return new Promise((resolve, reject) => {
        const pipeline = chain([
            fs.createReadStream(inputFile),
            parser(),
            streamObject(), // Extracts each {key, value} pair

            // This is the custom logic to detect non-readable data
            new Transform({
                objectMode: true,
                transform({ key, value }, encoding, callback) {
                    // Logic: If it's a Buffer, make it readable Base64
                    if (Buffer.isBuffer(value)) {
                        value = value.toString('base64');
                    }
                    // If it's an object/array, we leave it alone so stringer can format it
                    callback(null, { key, value });
                }
            }),

            // Makes the actual file look "readable" with 2-space indentation
            stringer({ makePath: true, indent: 2 }),
            fs.createWriteStream(outputFile)
        ]);

        pipeline.on('finish', () => {
            console.log("File is now readable and formatted!");
            resolve();
        });

        pipeline.on('error', (err) => {
            console.error("Readable conversion failed:", err);
            reject(err);
        });
    });
}


const inputdata = {
    image: "https://static.vecteezy.com/system/resources/thumbnails/057/068/323/small/single-fresh-red-strawberry-on-table-green-background-food-fruit-sweet-macro-juicy-plant-image-photo.jpg" // Example image URL
};

async function addJsonWithImageToDB() {
    let connection;
    try {
        config.database = "fm"; // Set your database name here
        let tableName = "image_store"; // Set your table name here
        let rowData = inputdata; // Set your row data here
        let imageColumnName = "image"; // e.g., "image"
        let imageUrlField = "image"; // e.g., "image_url"
        connection = await mysql.createConnection(config);

        // 1. Download the image from the link
        const response = await fetch(rowData[imageUrlField]);
        if (!response.ok) throw new Error(`Failed to fetch image: ${response.statusText}`);

        const imageArrayBuffer = await response.arrayBuffer();
        const imageBuffer = Buffer.from(imageArrayBuffer);

        // 2. Prepare the data
        // We remove the URL field and add the raw Buffer for the BLOB column
        const { [imageUrlField]: removedUrl, ...otherFields } = rowData;
        otherFields[imageColumnName] = imageBuffer;

        // 3. Build Dynamic SQL
        const columns = Object.keys(otherFields).map(col => `\`${col}\``).join(', ');
        const placeholders = Object.keys(otherFields).map(() => '?').join(', ');
        const values = Object.values(otherFields);

        const sql = `INSERT INTO \`${tableName}\` (${columns}) VALUES (${placeholders})`;

        // 4. Execute
        const [result] = await connection.execute(sql, values);

        return { success: true, insertId: result.insertId };

    } catch (error) {
        console.error("Insertion Error:", error.message);
        return { success: false, error: error.message };
    } finally {
        if (connection) await connection.end();
    }
}







/**
 * Checks memory pressure and triggers a cleanup only if necessary.
 * @param {number} threshold - Percentage (0-100). Only cleans if usage is higher.
 */

const { get } = require("http");
async function saveFileSafely(buffer, filePath) {
    return new Promise((resolve, reject) => {
        // 1. Create a Write Stream
        const stream = fs.createWriteStream(filePath);

        // 2. Handle errors (disk full, no permission, etc.)
        stream.on('error', (err) => {
            reject(err);
        });

        // 3. Handle completion
        stream.on('finish', () => {
            resolve(true);
        });

        // 4. Write the data
        // For very large buffers, .end() is better than .write() + .end()
        stream.end(buffer);
    });
}

const validatedData = {
    transaction_type: [
        'payment',
        'payout',
        'diposit', // (Keeping your original spelling; standard is 'deposit')
        'refund',
        'chargeback',
        'withdrawal',
        'transfer',
        'fee',
        'adjustment',
        'reversal',
        'authorization',
        'capture',
        'void',
        'dispute',
        'subscription',
        'invoice_payment',
        'remittance'
    ],
    transaction_id: 'KJS531SAF',
    amount: 10000,
    customer_name: 'Manik Ahmed',
    address: 'Subhadda Poscimpara, Keranigonj, Dhaka-1310',
    payment_method: 'Virtual Master Card',
    email: 'mawog.manik@gmail.com',
    phone: '01836699252',
    created_at: new Date()
}
const transaction_type = [
    'payment',
    'payout',
    'diposit', // (Keeping your original spelling; standard is 'deposit')
    'refund',
    'chargeback',
    'withdrawal',
    'transfer',
    'fee',
    'adjustment',
    'reversal',
    'authorization',
    'capture',
    'void',
    'dispute',
    'subscription',
    'invoice_payment',
    'remittance'
];
const userNames = [
    'Alexander Wright', 'Sophia Martinez', 'Liam Gallagher', 'Olivia Chen', 'Ethan Brooks',
    'Ava Patel', 'Marcus Vance', 'Isabella Rossi', 'Lucas Silva', 'Mia Tanaka',
    'Benjamin Hayes', 'Charlotte Dubois', 'Oliver Novak', 'Emma Johansson', 'Daniel Kim',
    'James Carter', 'Amelia Smith', 'Benjamin Jones', 'Harper Brown', 'Michael Miller',
    'Evelyn Davis', 'William Rodriguez', 'Abigail Martinez', 'David Hernandez', 'Emily Lopez',
    'Richard Gonzalez', 'Elizabeth Wilson', 'Joseph Anderson', 'Sofia Thomas', 'Thomas Taylor',
    'Avery Moore', 'Charles Jackson', 'Ella Martin', 'Christopher Lee', 'Madison Perez',
    'Daniel Thompson', 'Scarlett White', 'Matthew Harris', 'Victoria Sanchez', 'Anthony Clark',
    'Aria Ramirez', 'Mark Lewis', 'Grace Robinson', 'Donald Walker', 'Chloe Young',
    'Steven Allen', 'Camila King', 'Paul Wright', 'Penelope Scott', 'Andrew Torres',
    'Riley Nguyen', 'Joshua Hill', 'Layla Flores', 'Kenneth Green', 'Lillian Adams',
    'Kevin Nelson', 'Nora Baker', 'Brian Hall', 'Zoey Rivera', 'George Campbell',
    'Mila Mitchell', 'Edward Carter', 'Elena Roberts', 'Ronald Gomez', 'Violet Phillips',
    'Timothy Evans', 'Aurora Turner', 'Jason Diaz', 'Hazel Parker', 'Jeffrey Cruz',
    'Luna Edwards', 'Ryan Collins', 'Savannah Reyes', 'Jacob Stewart', 'Brooklyn Morris',
    'Gary Rogers', 'Bella Morales', 'Nicholas Murphy', 'Claire Cook', 'Eric Rogers',
    'Skylar Rogers', 'Jonathan Morgan', 'Lucy Peterson', 'Stephen Cooper', 'Anna Reed',
    'Larry Bailey', 'Samantha Bell', 'Justin Reed', 'Caroline Kelly', 'Scott Howard',
    'Genesis Ward', 'Brandon Cox', 'Aaliyah Diaz', 'Gregory Richardson', 'Kennedy Wood',
    'Samuel Watson', 'Allison Brooks', 'Raymond Bennett', 'Alice Gray', 'Patrick James',
    'Madeline Hughes', 'Jack Price', 'Cora Alvarez', 'Dennis Castillo', 'Ruby Sanders',
    'Jerry Patel', 'Eva Myers', 'Tyler Long', 'Serenity Ross', 'Aaron Foster',
    'Aubrey Jimenez', 'Jose Porter', 'Autumn Wallace', 'Adam Hamilton', 'Gianna Graham',
    'Nathan Sullivan', 'Valentina Wallace', 'Douglas West', 'Nova Cole', 'Peter Jordan',
    'Nevaeh Reynolds', 'Walter Griffin', 'Quinn Fisher', 'Harold Ellis', 'Lydia Harrison',
    'Kyle Gibson', 'Peyton Mcdonald', 'Carl Cruz', 'Piper Marshall', 'Arthur Ortiz',
    'Jasmine Gomez', 'Ryan Murray', 'Brielle Freeman', 'Roger Wells', 'Isla Webb',
    'Lawrence Simpson', 'Ariana Stevens', 'Albert Tucker', 'Melanie Porter', 'Joe Hunter',
    'Liliana Hicks', 'Christian Crawford', 'Adalyn Henry', 'Albert Boyd', 'Maya Mason',
    'Willie Morales', 'Gabriella Kennedy', 'Roy Price', 'Kinsley Weaver', 'Alan Simmons',
    'Adeline Patterson', 'Juan Foster', 'Amara Gonzalez', 'Louis Bryant', 'Zuri Henderson',
    'Harry Alexander', 'Remi Russell', 'Wayne Griffin', 'Hadley Hayes', 'Billy Diaz',
    'Natalia Myers', 'Bruce Jenkins', 'Zara Ford', 'Eugene Perry', 'Millie Hamilton',
    'Ralph Powell', 'Leilani Sullivan', 'Roy Long', 'Kamila Reynolds', 'Eugene Fisher',
    'Kaitlyn Peterson', 'Louis Simmons', 'Maeve Foster', 'Harry Butler', 'Sloane Bryant',
    'Wayne Alexander', 'Oakley Russell', 'Alan Griffin', 'Celine Hayes', 'Billy Diaz',
    'Iris Myers', 'Bruce Jenkins', 'Zara Ford', 'Eugene Perry', 'Millie Hamilton',
    'Ralph Powell', 'Leilani Sullivan', 'Roy Long', 'Kamila Reynolds', 'Eugene Fisher',
    'Kaitlyn Peterson', 'Louis Simmons', 'Maeve Foster', 'Harry Butler', 'Sloane Bryant'
];
const internationalAddresses = [
    // North America
    "1428 Elm St, Los Angeles, CA 90026, USA",
    "742 Evergreen Terrace, Springfield, OR 97477, USA",
    "455 Boulevard René-Lévesque O, Montréal, QC H2Z 1Z3, Canada",
    "Av. President Masaryk 123, Polanco, CDMX, 11560, Mexico",

    // Europe
    "221B Baker St, London NW1 6XE, United Kingdom",
    "10 Rue de la Paix, 75002 Paris, France",
    "Friedrichstraße 95, 10117 Berlin, Germany",
    "Plaza Mayor 4, Centro, 28012 Madrid, Spain",
    "Via dei Condotti 86, 00187 Roma, RM, Italy",
    "Prinsengracht 263, 1016 GV Amsterdam, Netherlands",
    "Klarabergsgatan 50, 111 21 Stockholm, Sweden",
    "ul. Floriańska 15, 31-019 Kraków, Poland",

    // Asia & Middle East
    "1-1-2 Otemachi, Chiyoda-ku, Tokyo 100-0004, Japan",
    "Teheran-ro 521, Gangnam-gu, Seoul 06164, South Korea",
    "30 Raffles Place, Singapore 048622",
    "Connaught Place, Block E, New Delhi, Delhi 110001, India",
    "Nanjing Road No. 123, Huangpu District, Shanghai 200001, China",
    "Burj Khalifa Blvd, Downtown Dubai, United Arab Emirates",
    "12 Chamié Street, Achrafieh, Beirut, Lebanon",

    // South America
    "Av. Paulista 1000, Bela Vista, São Paulo - SP, 01310-100, Brazil",
    "Av. del Libertador 1400, C1425AAA Buenos Aires, Argentina",
    "Calle 85 #11-53, Chico, Bogotá, 110221, Colombia",
    "Av. Larco 456, Miraflores, Lima 15074, Peru",

    // Oceania
    "456 George St, Sydney NSW 2000, Australia",
    "82 Queen St, Auckland CBD, Auckland 1010, New Zealand",

    // Africa
    "50 Long St, Cape Town City Centre, Cape Town, 8001, South Africa",
    "23 Alfred Rewane Rd, Ikoyi, Lagos 101233, Nigeria",
    "15 El-Ghad Street, Zamalek, Cairo 11561, Egypt",
    "Moi Avenue, Nairobi CBD, Nairobi, Kenya",

    // South Asia / Local Regional
    "House 12, Road 5, Dhanmondi R/A, Dhaka 1205, Bangladesh"
];
const paymentMethods = [
    'Virtual Master Card',
    'Physical Visa Credit',
    'American Express Gold',
    'Apple Pay',
    'Google Wallet',
    'PayPal Balance',
    'Stripe Checkout',
    'BKash SafePay', // Local dynamic payment channel
    'Nagad Wallet',
    'Discover Debit',
    'Revolut Disposable Card',
    'Wise Multi-Currency Account',
    'Klarna Pay in 4',
    'Crypto (USDC)',
    'Crypto (Bitcoin)',
    'SEPA Bank Transfer',
    'ACH Direct Deposit'
];
function generateTxnId() {
    return 'TXN-' + Math.random().toString(36).substring(2, 10).toUpperCase();
}
function generateRandomEmail(name, type = 'any') {
    // Fallback if no name is provided
    const cleanName = typeof name === 'string' && name.trim().length > 0
        ? name.toLowerCase().replace(/[^a-z0-9]/g, '')
        : Math.random().toString(36).substring(2, 8);

    const commonDomains = ['gmail.com', 'yahoo.com', 'outlook.com', 'icloud.com'];
    const corporateDomains = ['stripe.com', 'meta.com', 'microsoft.com', 'oracle.com', 'aws.amazon.com'];
    const regionalDomains = ['yahoo.co.uk', 'gmail.com.bd', 'unicef.org', 'mit.edu', 'ac.uk'];
    const disposableDomains = ['mailinator.com', 'sharklasers.com', 'tempmail.net', 'yopmail.com'];

    const pickRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];
    const randNum = () => Math.floor(100 + Math.random() * 9000); // 3-4 digit random string variations

    // Choose specific pool or default to completely random across all profiles
    let selectedDomain;
    switch (type) {
        case 'personal': selectedDomain = pickRandom(commonDomains); break;
        case 'corporate': selectedDomain = pickRandom(corporateDomains); break;
        case 'regional': selectedDomain = pickRandom(regionalDomains); break;
        case 'disposable': selectedDomain = pickRandom(disposableDomains); break;
        default: selectedDomain = pickRandom([...commonDomains, ...corporateDomains, ...regionalDomains, ...disposableDomains]);
    }

    // Add string variety formats (e.g., alex.943, alexander_wright2026, wright.alex)
    const formats = [
        `${cleanName}${randNum()}@${selectedDomain}`,
        `${cleanName}.${randNum()}@${selectedDomain}`,
        `contact.${cleanName}@${selectedDomain}`,
        `${cleanName}_dev@${selectedDomain}`,
        `${cleanName}@${selectedDomain}`
    ];

    return pickRandom(formats);
}
function generateRandomPhoneNumber(region = 'any') {
    const pickRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];
    const digitString = (length) => Array.from({ length }, () => Math.floor(Math.random() * 10)).join('');

    const regions = ['us', 'uk', 'bd', 'intl'];
    const activeRegion = region === 'any' ? pickRandom(regions) : region.toLowerCase();

    switch (activeRegion) {
        case 'us': {
            // US Format: +1 (AAA) NNN-NNNN
            const areaCode = pickRandom(['212', '310', '415', '646', '702']);
            return `+1 (${areaCode}) ${digitString(3)}-${digitString(4)}`;
        }
        case 'uk': {
            // UK Format: +44 7NNN NNNNNN (Mobile style)
            return `+44 7${digitString(3)} ${digitString(6)}`;
        }
        case 'bd': {
            // Bangladesh Format: +880 1NNN-NNNNNN
            const operatorCode = pickRandom(['3', '4', '5', '6', '7', '8', '9']); // 13, 14, 17, 19 etc.
            return `+880 1${operatorCode}${digitString(2)}-${digitString(6)}`;
        }
        case 'intl':
        default: {
            // Generic fallback international format
            const countryCode = pickRandom(['49', '33', '81', '61', '971']); // Germany, France, Japan, Australia, UAE
            return `+${countryCode} ${digitString(2)} ${digitString(3)} ${digitString(4)}`;
        }
    }
}
function generateRandomAmount() {
    // 1. Define typical transactional brackets to keep data looking realistic
    const brackets = [
        { min: 10, max: 100 },         // Micro-transactions / small retail
        { min: 100, max: 1000 },       // Standard retail / consumer bills
        { min: 1000, max: 50000 },     // B2B, payouts, or tech purchases
        { min: 50000, max: 10000000 }  // Enterprise, large remittances, maximum limit
    ];

    // 2. Pick a random bracket to determine order of magnitude
    const bracket = brackets[Math.floor(Math.random() * brackets.length)];

    // 3. Generate a random flat integer within the bracket boundaries
    const rawAmount = Math.floor(Math.random() * (bracket.max - bracket.min + 1)) + bracket.min;

    // 4. Force a clean round figure based on scale (e.g., matching common bills/notes)
    if (rawAmount >= 100000) {
        return Math.round(rawAmount / 10000) * 10000; // Rounds to nearest 10,000 for massive scale
    } else if (rawAmount >= 1000) {
        return Math.round(rawAmount / 100) * 100;     // Rounds to nearest 100 for mid scale
    } else if (rawAmount >= 100) {
        return Math.round(rawAmount / 10) * 10;       // Rounds to nearest 10 for low scale
    }

    return rawAmount; // Returns exact flat unit under 100
}
const jtd = require("./user_tables.js");
const advanced_store_data = {
    // --- Binary / Object Storage ---
    // Using hex-strings or buffers which map directly to binary columns
    secure_token: Buffer.from("a1b2c3d4e5f67890f1e2d3c4b5a67890", "hex"),
    session_signature: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    thumbnail_avatar: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==", // Base64 or raw chunk
    user_attachment: "Raw file binary payload, buffer data, or PDF byte streams go here",
    media_backup: "Mid-sized backup archive binary data blob stream",
    system_image_dump: "Large core system image memory layout binary chunk data",

    // --- Sets & Documents ---
    // SET handles single strings or multiple values comma-separated
    account_privileges: "READ,WRITE,EXECUTE",
    audit_metadata: JSON.stringify({
        ip: "192.168.1.1",
        device: "MacBook Pro",
        os: "macOS",
        browser: "Chrome"
    }),

    // --- Spatial / GIS Geometry Types (Using Well-Known Text Syntax) ---
    generic_shape: "ST_GeomFromText('POINT(0 0)')",
    location_coordinate: "ST_GeomFromText('POINT(23.8103 90.4125)')", // Lat/Long coordinates
    route_path: "ST_GeomFromText('LINESTRING(0 0, 1 1, 2 2, 4 4)')",
    boundary_zone: "ST_GeomFromText('POLYGON((0 0, 0 10, 10 10, 10 0, 0 0))')", // Closed loop
    cluster_nodes: "ST_GeomFromText('MULTIPOINT(0 0, 1 2, 2 3, 5 1)')",
    metro_transit_lines: "ST_GeomFromText('MULTILINESTRING((0 0, 5 5), (10 10, 20 20))')",
    territory_regions: "ST_GeomFromText('MULTIPOLYGON(((-60.0 -51.5, -60.0 -51.2, -59.5 -51.2, -59.5 -51.5, -60.0 -51.5)), ((-59.3 -51.6, -59.3 -51.3, -58.5 -51.3, -58.5 -51.6, -59.3 -51.6)))')",
    spatial_aggregate: "ST_GeomFromText('GEOMETRYCOLLECTION(POINT(4 6), LINESTRING(4 6, 7 10))')"
};
const upl = require("./uploaddata.js");
async function test() {
    const config = {
        port: "3301",
        host: "localhost",
        user: "root",
        password: "1234",
        dropdb: true,
        droptable: true,
        dropcol: true,
        forceupdatecolumn: true,
        forcedeletecolumn: true,
        sep: "_",
        "work mode": "download",
        "folder path": "./",
        "full backup": true,
        "force download": false
    };
    const eng = require("./index")
    const runtable = await eng(config);
    console.log(runtable)

    // const addRec = await fncs.addRecord(config, 'fm', 'advanced_store', advanced_store_data);
    // console.log(addRec)


    // const rootPath = await upload.uploadBackup(config, "./backup.zip")
    // console.log(rootPath)
    // const upldata = require("./uploaddata.js")
    // const paths = await fncs.getColumnDetails(config, 'main', 'setting', 'user_id');
    // console.log(paths)

}
test();

